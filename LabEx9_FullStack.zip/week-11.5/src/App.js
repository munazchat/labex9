import logo from './logo.svg';
import './App.css';
import Userdata from './Userdata'
import PersonList from './PersonList'
function App() {
  return (
    <div className="App">
     <h1> My list </h1>

     <Userdata/>
     <PersonList/>
      
    </div>
  );
}

export default App;
